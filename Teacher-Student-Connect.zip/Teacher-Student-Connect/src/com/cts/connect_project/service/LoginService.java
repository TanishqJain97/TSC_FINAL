package com.cts.connect_project.service;

import com.cts.connect_project.bean.Login;

public interface LoginService {
	
	public int authenticateUser(Login login);

}
