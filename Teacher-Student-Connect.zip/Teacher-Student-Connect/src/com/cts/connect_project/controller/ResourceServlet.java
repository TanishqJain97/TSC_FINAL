package com.cts.connect_project.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.cts.connect_project.bean.Resource;
import com.cts.connect_project.service.ResourceService;
import com.cts.connect_project.service.ResourceServiceImpl;

/**
 * Servlet implementation class ResourceServlet
 */

@MultipartConfig

public class ResourceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	ResourceService resourceService = new ResourceServiceImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResourceServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		Resource resource = new Resource();
		String subject = request.getParameter("subject");
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String year = request.getParameter("year");
		PrintWriter out = response.getWriter();

		InputStream inputStream = null; // input stream of the upload file

		
		// obtains the upload file part in this multipart request
		Part filePart = request.getPart("image");
		if (filePart != null) {
			// prints out some information for debugging
			System.out.println(filePart.getName());
			System.out.println(filePart.getSize());
			System.out.println(filePart.getContentType());

			// obtains input stream of the upload file
			inputStream = filePart.getInputStream();
		}
		InputStream inputStream2 = null;
		Part filePart2 = request.getPart("file");
		if (filePart2 != null) {
			// prints out some information for debugging
			System.out.println(filePart2.getName());
			System.out.println(filePart2.getSize());
			System.out.println(filePart2.getContentType());

			// obtains input stream of the upload file
			inputStream2 = filePart2.getInputStream();
		}
		resource.setSubject(subject);
		resource.setTitle(title);
		resource.setAuthor(author);
		resource.setYear(year);
		resource.setImage(inputStream);
		resource.setFile(inputStream2);

		System.out.println(resource.getSubject());
		
		  if(resourceService.addResource(resource)==1) {
		  request.getRequestDispatcher("addedSuccessfully.jsp").forward(request, response); 
		  request.setAttribute("addResourceMsg", "Resource Added");
		  session.setAttribute("addResourceMsg", "Resource Added");
		  
		  }
		  
		  else { request.getRequestDispatcher("submitResources.jsp").forward(request,response);
		  request.setAttribute("addResourceMsg", "Resource Not Added");
		  session.setAttribute("addResourceMsg", "Resource Added");
		  
		  }
		 	}

}